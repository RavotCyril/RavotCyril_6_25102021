HOT TAKES  ( Sauces piquantes )

Pour Visualiser l'application. Vous aurez besoin de Node (Node.js est une plateforme logicielle libre en JavaScript,) et d'installer npm sur votre machine.

Intallation

Clonez le repositery : https://github.com/OpenClassrooms-Student-Center/Web-Developer-P6

Positionnez-vous dans le dossier du projet puis suivez la procédure suivante via votre terminal :

Backend :

1- Depuis le dossier du projet : cd backend
2- npm install
3- nodemon server


Frontend :

1- Depuis le dossier du projet : cd frontend
2- run npm install et run npm install --save-dev run-script-os. 
3- 'npm start'
Cela devrait à la fois exécuter le serveur local et lancer votre navigateur.

Si votre navigateur ne démarre pas ou affiche une erreur 404, accédez à http://localhost:8080 dans votre navigateur.
Utiliser Ctrl+C dans le terminal pour arrêter le serveur local. 


Pour pouvoir vérifier les versions.

1- Depuis le dossier du projet : cd Web-Developer-P6
2-  ng version

Resultat : 

Angular CLI: 13.0.3
Node: 14.18.1
Package Manager: npm 8.1.2
OS: win32 x64

